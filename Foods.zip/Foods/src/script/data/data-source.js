import foods from './foods.js';

class DataSource {
  static searchfood(keyword) {
    return new Promise((resolve, reject) => {
      const filteredfoods = foods.filter(food => food.name.toUpperCase().includes(keyword.toUpperCase()));
      
      if (filteredfoods.length) {
        resolve(filteredfoods);
      } else {
        reject(`${keyword} is not found`);
      }
    });
  }
}

export default DataSource;