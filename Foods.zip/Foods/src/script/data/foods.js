const foods = [
  {
    name: 'Nasi Goreng',
    fanArt: 'https://img.kurio.network/ewrCJ9eRNpljU-80vrqWDQkN7o4=/1200x675/filters:quality(80)/https://kurio-img.kurioapps.com/20/10/10/a7e9eaa0-1c22-42b0-a11f-0a5ad1d30126.jpeg',
    description: 'Nasi goreng adalah hidangan nasi yang digoreng dalam minyak atau margarin, biasanya dengan telur dan bumbu seperti bawang putih, bawang merah, ketumbar, kecap, dan cabai.',
  },
  {
    name: 'Pizza',
    fanArt: './public/img/pizza.jpg',
    description: 'Pizza adalah hidangan berupa roti pipih yang dilapisi saus tomat dan berbagai macam topping seperti keju, daging, sayuran, dan bumbu.',
  },
  {
    name: 'Sushi',
    fanArt: './public/img/sushi.jpg',
    description: 'Sushi adalah hidangan Jepang yang terdiri dari nasi yang diberi topping berupa ikan, telur, atau sayuran, yang seringkali disajikan dengan saus kedelai dan wasabi.',
  },
  {
    name: 'Burger',
    fanArt: './public/img/burger.jpg',
    description: 'Burger adalah hidangan berupa daging cincang yang dibentuk bulat dan biasanya disajikan di dalam roti, seringkali dengan keju, sayuran, dan saus.',
  },
];

export default foods;